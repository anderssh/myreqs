import nxapi_plumbing


def test_import():
    assert True
