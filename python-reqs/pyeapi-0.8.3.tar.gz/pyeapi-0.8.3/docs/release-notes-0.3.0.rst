######
v0.3.0
######

2015-05-04

- fixes an issue with configuring stp portfast edge correctly
- fixes #13
- fixes #11
- added initial support for system api module
- added initial support for acl api module (standard)
- added initial api support for mlag configuration
- added tag feature to eapi.conf
